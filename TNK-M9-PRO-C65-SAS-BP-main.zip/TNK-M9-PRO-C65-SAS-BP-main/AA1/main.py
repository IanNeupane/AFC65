# Importing Library
import numpy as np
import cv2

# Define the input and output paths
inputPath = 'static/img1.png'

# Load the color image
originalImage = cv2.imread(inputPath)

# ------------Rotate the image --------------

# Rotate the image


# Save the image to disk
outputPath = 'converted/rotated.png'


# Display the image


# Display a message indicating that the image has been saved
# print('Rotated image saved to disk : ' + outputPath)
