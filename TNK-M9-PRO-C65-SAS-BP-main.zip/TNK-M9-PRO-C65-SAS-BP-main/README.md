# TNK-M9-PRO-C65-SAS-BP

Class 65 student activities boilerplate

To run the project follow the below commands:

```
* git clone https://github.com/Tynker-Computer-Vision/TNK-M9-PRO-C65-SAS-BP.git
* cd TNK-M9-PRO-C65-SAS-BP
* python3 -m venv myenv
* source myenv/bin/activate
* pip install -r requirements.txt
```

---
